# -*- coding: utf-8 -*-
#      __    ____  ____  _   _____  _____________________
#     / /   / __ \/ __ \/ | / /   |/_  __/  _/ ____/ ___/
#    / /   / / / / / / /  |/ / /| | / /  / // /    \__ \
#   / /___/ /_/ / /_/ / /|  / ___ |/ / _/ // /___ ___/ /
#  /_____/\____/\____/_/ |_/_/  |_/_/ /___/\____//____/
#

from resources.lib.modules.control import addonPath, addonId, getLEVersion, joinPath
from resources.lib.windows.textviewer import TextViewerXML


def get():
	le_path = addonPath(addonId())
	le_version = getLEVersion()
	changelogfile = joinPath(le_path, 'changelog.txt')
	r = open(changelogfile)
	text = r.read()
	r.close()
	heading = '[B]LE -  v%s - ChangeLog[/B]' % le_version
	windows = TextViewerXML('textviewer.xml', le_path, heading=heading, text=text)
	windows.run()
	del windows