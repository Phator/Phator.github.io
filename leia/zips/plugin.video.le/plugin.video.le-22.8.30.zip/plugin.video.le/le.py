# -*- coding: utf-8 -*-
#      __    ____  ____  _   _____  _____________________
#     / /   / __ \/ __ \/ | / /   |/_  __/  _/ ____/ ___/
#    / /   / / / / / / /  |/ / /| | / /  / // /    \__ \
#   / /___/ /_/ / /_/ / /|  / ___ |/ / _/ // /___ ___/ /
#  /_____/\____/\____/_/ |_/_/  |_/_/ /___/\____//____/
#

from sys import argv
try: #Py2
    from urlparse import parse_qsl
except ImportError: #Py3
    from urllib.parse import parse_qsl
from resources.lib.modules import router

if __name__ == '__main__':
    try:
        url = dict(parse_qsl(argv[2].replace('?', '')))
    except:
        url = {}
    router.router(url)